module.exports = {
    url : "mongodb://mongoadmin:Ree58WssFhjOPplw28s@13.234.154.219:27017/xbvts?directConnection=true"
}