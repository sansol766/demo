module.exports ={
    "jwtKeys" :{
        'SECRET_KEY': 'sevak - secret',
    }
}